# HX711
Procedural implementation of HX711 library with HAL for STM32
